# Lab06 - Estudiantes

CRUD de estudiantes con JavaScript, Supabase y SweetAlert2.
